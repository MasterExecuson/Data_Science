# FBCSP Toolbox

This contains the codebase for the FBCSP Toolbox.
Please refer to <a href="https://fbcsptoolbox.github.io">fbcsptoolbox.github.io</a> for information on the toolbox.

For reporting any problems, please use the issues tab of this repo.
